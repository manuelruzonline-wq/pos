<?php
/**
 * GATO PINTO POS - Configuración General
 * Edita este archivo con tus datos de conexión
 */

// ============================================
// BASE DE DATOS PRINCIPAL (POS)
// ============================================
define('POS_DB_HOST', 'localhost');
define('POS_DB_USER', 'tu_usuario_mysql');
define('POS_DB_PASS', 'tu_contraseña_mysql');
define('POS_DB_NAME', 'gato_pinto_pos');

// ============================================
// BASE DE DATOS MIESPACIO (Clientes)
// ============================================
define('MIESPACIO_DB_HOST', 'localhost');
define('MIESPACIO_DB_USER', 'tu_usuario_mysql');
define('MIESPACIO_DB_PASS', 'tu_contraseña_mysql');
define('MIESPACIO_DB_NAME', 'miespacio_db');
define('MIESPACIO_TABLE_USERS', 'usuarios'); // Nombre de la tabla de usuarios

// ============================================
// BASE DE DATOS WORDPRESS (WooCommerce)
// ============================================
define('WP_DB_HOST', 'localhost');
define('WP_DB_USER', 'tu_usuario_mysql');
define('WP_DB_PASS', 'tu_contraseña_mysql');
define('WP_DB_NAME', 'wordpress_db');
define('WP_TABLE_PREFIX', 'wp_'); // Prefijo de tablas de WordPress

// ============================================
// CONFIGURACIÓN GENERAL
// ============================================
define('SITE_URL', 'https://tudominio.com'); // URL de tu sitio
define('TIMEZONE', 'America/Mexico_City');
define('DEBUG_MODE', false); // Cambiar a false en producción

// ============================================
// SEGURIDAD
// ============================================
define('SESSION_LIFETIME', 28800); // 8 horas
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_TIMEOUT', 900); // 15 minutos

// ============================================
// ARCHIVOS
// ============================================
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('UPLOAD_URL', SITE_URL . '/uploads/');
define('MAX_UPLOAD_SIZE', 5242880); // 5MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'pdf']);

// ============================================
// NO EDITAR DEBAJO DE ESTA LÍNEA
// ============================================

// Configurar zona horaria
date_default_timezone_set(TIMEZONE);

// Configuración de errores
if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Configuración de sesión
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 0); // Cambiar a 1 si usas HTTPS
ini_set('session.gc_maxlifetime', SESSION_LIFETIME);

// ============================================
// CONEXIÓN A BASE DE DATOS PRINCIPAL (POS)
// ============================================
try {
    $pdo = new PDO(
        "mysql:host=" . POS_DB_HOST . ";dbname=" . POS_DB_NAME . ";charset=utf8mb4",
        POS_DB_USER,
        POS_DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
        ]
    );
} catch(PDOException $e) {
    if (DEBUG_MODE) {
        die("Error de conexión POS: " . $e->getMessage());
    } else {
        die("Error de conexión a la base de datos. Contacta al administrador.");
    }
}

// ============================================
// FUNCIONES DE UTILIDAD
// ============================================

/**
 * Verificar autenticación
 */
function checkAuth() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'message' => 'No autorizado. Inicia sesión.'
        ]);
        exit;
    }
    
    return $_SESSION;
}

/**
 * Verificar si es administrador
 */
function isAdmin() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

/**
 * Limpiar entrada de datos
 */
function cleanInput($data) {
    if (is_array($data)) {
        return array_map('cleanInput', $data);
    }
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

/**
 * Generar número de venta único
 */
function generateSaleNumber($pdo) {
    $prefix = 'GP';
    $date = date('Ymd');
    
    $stmt = $pdo->prepare("
        SELECT sale_number 
        FROM sales 
        WHERE sale_number LIKE ? 
        ORDER BY id DESC 
        LIMIT 1
    ");
    $stmt->execute([$prefix . $date . '%']);
    $last = $stmt->fetch();
    
    if ($last) {
        $lastNumber = intval(substr($last['sale_number'], -4));
        $newNumber = $lastNumber + 1;
    } else {
        $newNumber = 1;
    }
    
    return $prefix . $date . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
}

/**
 * Registrar actividad
 */
function logActivity($pdo, $action, $entity_type = null, $entity_id = null, $description = null) {
    try {
        $user_id = $_SESSION['user_id'] ?? null;
        $ip = $_SERVER['REMOTE_ADDR'] ?? null;
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? null;
        
        $stmt = $pdo->prepare("
            INSERT INTO activity_log (user_id, action, entity_type, entity_id, description, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([$user_id, $action, $entity_type, $entity_id, $description, $ip, $user_agent]);
    } catch(PDOException $e) {
        // Log silenciosamente, no interrumpir la operación principal
        error_log("Error logging activity: " . $e->getMessage());
    }
}

/**
 * Obtener configuración
 */
function getSetting($pdo, $key, $default = null) {
    try {
        $stmt = $pdo->prepare("SELECT setting_value, setting_type FROM settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $result = $stmt->fetch();
        
        if (!$result) {
            return $default;
        }
        
        $value = $result['setting_value'];
        
        // Convertir según el tipo
        switch ($result['setting_type']) {
            case 'boolean':
                return (bool) $value;
            case 'number':
                return is_numeric($value) ? +$value : $default;
            case 'json':
                return json_decode($value, true) ?? $default;
            default:
                return $value;
        }
    } catch(PDOException $e) {
        return $default;
    }
}

/**
 * Guardar configuración
 */
function setSetting($pdo, $key, $value, $type = 'string') {
    try {
        // Si es JSON, codificar
        if ($type === 'json') {
            $value = json_encode($value);
        }
        
        $stmt = $pdo->prepare("
            INSERT INTO settings (setting_key, setting_value, setting_type) 
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE setting_value = ?, setting_type = ?
        ");
        
        $stmt->execute([$key, $value, $type, $value, $type]);
        return true;
    } catch(PDOException $e) {
        return false;
    }
}

/**
 * Conectar a base de datos MiEspacio
 */
function getMiEspacioDB() {
    static $miespacio_pdo = null;
    
    if ($miespacio_pdo === null) {
        try {
            $miespacio_pdo = new PDO(
                "mysql:host=" . MIESPACIO_DB_HOST . ";dbname=" . MIESPACIO_DB_NAME . ";charset=utf8mb4",
                MIESPACIO_DB_USER,
                MIESPACIO_DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                ]
            );
        } catch(PDOException $e) {
            error_log("Error conectando a MiEspacio: " . $e->getMessage());
            return null;
        }
    }
    
    return $miespacio_pdo;
}

/**
 * Conectar a base de datos WordPress
 */
function getWordPressDB() {
    static $wp_pdo = null;
    
    if ($wp_pdo === null) {
        try {
            $wp_pdo = new PDO(
                "mysql:host=" . WP_DB_HOST . ";dbname=" . WP_DB_NAME . ";charset=utf8mb4",
                WP_DB_USER,
                WP_DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                ]
            );
        } catch(PDOException $e) {
            error_log("Error conectando a WordPress: " . $e->getMessage());
            return null;
        }
    }
    
    return $wp_pdo;
}

/**
 * Formatear moneda
 */
function formatCurrency($amount, $symbol = '$') {
    return $symbol . number_format($amount, 2, '.', ',');
}

/**
 * Respuesta JSON
 */
function jsonResponse($success, $message = '', $data = null, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    
    $response = [
        'success' => $success,
        'message' => $message
    ];
    
    if ($data !== null) {
        $response['data'] = $data;
    }
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}
?>
