/**
 * GATO PINTO POS - Vistas de la Aplicación
 * Todas las pantallas principales
 */

// PLACEHOLDER: Vista de venta (se desarrollará completo)
async function loadSellView() {
    const content = document.getElementById('appContent');
    content.innerHTML = `
        <div class="sell-view">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-cash-register"></i>
                        Punto de Venta
                    </h2>
                </div>
                <div class="card-body">
                    <p class="text-center text-muted">
                        Vista de venta en desarrollo completo...
                        <br>Incluirá búsqueda de productos, carrito, y checkout
                    </p>
                </div>
            </div>
        </div>
    `;
}

async function loadProductsView() {
    const content = document.getElementById('appContent');
    content.innerHTML = `
        <div class="products-view">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-box"></i>
                        Gestión de Productos
                    </h2>
                    <button class="btn btn-primary" onclick="showAddProduct()">
                        <i class="fas fa-plus"></i>
                        Agregar Producto
                    </button>
                </div>
                <div class="card-body">
                    <p class="text-muted">Cargando productos...</p>
                </div>
            </div>
        </div>
    `;
}

async function loadCategoriesView() {
    const content = document.getElementById('appContent');
    content.innerHTML = `
        <div class="categories-view">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-tags"></i>
                        Categorías
                    </h2>
                </div>
                <div class="card-body">
                    <p class="text-muted">Vista de categorías...</p>
                </div>
            </div>
        </div>
    `;
}

async function loadSalesView() {
    const content = document.getElementById('appContent');
    content.innerHTML = `
        <div class="sales-view">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-receipt"></i>
                        Historial de Ventas
                    </h2>
                </div>
                <div class="card-body">
                    <p class="text-muted">Cargando ventas...</p>
                </div>
            </div>
        </div>
    `;
}

async function loadCustomersView() {
    const content = document.getElementById('appContent');
    content.innerHTML = `
        <div class="customers-view">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-users"></i>
                        Clientes
                    </h2>
                </div>
                <div class="card-body">
                    <p class="text-muted">Integración con MiEspacio...</p>
                </div>
            </div>
        </div>
    `;
}

async function loadCouponsView() {
    const content = document.getElementById('appContent');
    content.innerHTML = `
        <div class="coupons-view">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-ticket-alt"></i>
                        Cupones de Descuento
                    </h2>
                    <button class="btn btn-primary">
                        <i class="fas fa-plus"></i>
                        Nuevo Cupón
                    </button>
                </div>
                <div class="card-body">
                    <p class="text-muted">Sistema de cupones...</p>
                </div>
            </div>
        </div>
    `;
}

async function loadReportsView() {
    const content = document.getElementById('appContent');
    content.innerHTML = `
        <div class="reports-view">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-chart-line"></i>
                        Reportes Detallados
                    </h2>
                </div>
                <div class="card-body">
                    <p class="text-muted">Reportes por categoría, productos, etc...</p>
                </div>
            </div>
        </div>
    `;
}

async function loadSyncView() {
    const content = document.getElementById('appContent');
    content.innerHTML = `
        <div class="sync-view">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-sync-alt"></i>
                        Sincronización WooCommerce
                    </h2>
                </div>
                <div class="card-body">
                    <p class="text-muted">Sistema de sincronización...</p>
                </div>
            </div>
        </div>
    `;
}

async function loadSettingsView() {
    const content = document.getElementById('appContent');
    content.innerHTML = `
        <div class="settings-view">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-cog"></i>
                        Configuración
                    </h2>
                </div>
                <div class="card-body">
                    <p class="text-muted">Configuración del sistema...</p>
                </div>
            </div>
        </div>
    `;
}

