// Helpers de API
console.log('API helpers loaded');
