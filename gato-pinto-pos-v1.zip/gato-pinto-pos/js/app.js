/**
 * GATO PINTO POS - Aplicación Principal
 */

// Estado global de la aplicación
const APP = {
    currentUser: null,
    currentView: 'sell',
    settings: {},
    cart: [],
    products: [],
    categories: [],
    customers: []
};

// ============================================
// INICIALIZACIÓN
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    console.log('🐱 Gato Pinto POS iniciando...');
    checkSession();
    setupEventListeners();
});

// ============================================
// AUTENTICACIÓN
// ============================================
async function checkSession() {
    try {
        const response = await fetch('api/auth.php?action=check');
        const data = await response.json();
        
        if (data.success) {
            APP.currentUser = data.data.user;
            showApp();
        } else {
            showLogin();
        }
    } catch (error) {
        console.error('Error checking session:', error);
        showLogin();
    }
}

async function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const submitBtn = e.target.querySelector('button[type="submit"]');
    const btnText = submitBtn.querySelector('.btn-text');
    const btnLoader = submitBtn.querySelector('.btn-loader');
    const errorDiv = document.getElementById('loginError');
    
    // Mostrar loader
    btnText.classList.add('hidden');
    btnLoader.classList.remove('hidden');
    submitBtn.disabled = true;
    errorDiv.classList.add('hidden');
    
    try {
        const response = await fetch('api/auth.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'login',
                username,
                password
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            APP.currentUser = data.data.user;
            showToast('¡Bienvenido!', `Hola ${data.data.user.name}`, 'success');
            showApp();
        } else {
            errorDiv.textContent = data.message;
            errorDiv.classList.remove('hidden');
        }
    } catch (error) {
        console.error('Login error:', error);
        errorDiv.textContent = 'Error de conexión. Intenta de nuevo.';
        errorDiv.classList.remove('hidden');
    } finally {
        btnText.classList.remove('hidden');
        btnLoader.classList.add('hidden');
        submitBtn.disabled = false;
    }
}

async function handleLogout() {
    if (!confirm('¿Cerrar sesión?')) return;
    
    try {
        await fetch('api/auth.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'logout' })
        });
        
        APP.currentUser = null;
        APP.cart = [];
        showLogin();
        showToast('Sesión cerrada', 'Hasta pronto', 'info');
    } catch (error) {
        console.error('Logout error:', error);
    }
}

function showLogin() {
    document.getElementById('loginScreen').classList.add('active');
    document.getElementById('appScreen').classList.remove('active');
}

function showApp() {
    document.getElementById('loginScreen').classList.remove('active');
    document.getElementById('appScreen').classList.add('active');
    
    // Actualizar UI con datos del usuario
    document.getElementById('userName').textContent = APP.currentUser.name;
    document.getElementById('userRole').textContent = APP.currentUser.role === 'admin' ? 'Administrador' : 'Cajero';
    
    // Ocultar items de admin si no es admin
    if (APP.currentUser.role !== 'admin') {
        document.querySelectorAll('.admin-only').forEach(el => {
            el.style.display = 'none';
        });
    }
    
    // Cargar configuración
    loadSettings();
    
    // Cargar vista inicial
    loadView('sell');
}

// ============================================
// NAVEGACIÓN
// ============================================
function setupEventListeners() {
    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Logout button
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    
    // Menu toggle
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    const closeSidebar = document.getElementById('closeSidebar');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', () => {
            sidebar.classList.add('active');
            sidebarOverlay.classList.add('active');
        });
    }
    
    if (closeSidebar) {
        closeSidebar.addEventListener('click', () => {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        });
    }
    
    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', () => {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        });
    }
    
    // Menu items
    document.querySelectorAll('.menu-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const view = item.getAttribute('data-view');
            
            // Actualizar menú activo
            document.querySelectorAll('.menu-item').forEach(mi => mi.classList.remove('active'));
            item.classList.add('active');
            
            // Cerrar sidebar en mobile
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
            
            // Cargar vista
            loadView(view);
        });
    });
}

function loadView(viewName) {
    APP.currentView = viewName;
    
    // Actualizar título
    const titles = {
        'sell': 'Vender',
        'sales': 'Historial de Ventas',
        'products': 'Productos',
        'categories': 'Categorías',
        'stock': 'Control de Stock',
        'customers': 'Clientes',
        'coupons': 'Cupones',
        'reports': 'Reportes',
        'analytics': 'Análisis',
        'sync': 'Sincronización',
        'settings': 'Configuración',
        'users': 'Usuarios'
    };
    
    document.getElementById('headerTitle').textContent = titles[viewName] || 'Gato Pinto POS';
    
    // Cargar contenido de la vista
    const content = document.getElementById('appContent');
    
    // Mostrar loader
    content.innerHTML = `
        <div class="loading-screen">
            <i class="fas fa-spinner fa-spin fa-3x" style="color: var(--orange-primary);"></i>
            <p style="margin-top: 20px; color: var(--gray-500);">Cargando...</p>
        </div>
    `;
    
    // Cargar vista específica
    setTimeout(() => {
        switch(viewName) {
            case 'sell':
                loadSellView();
                break;
            case 'products':
                loadProductsView();
                break;
            case 'categories':
                loadCategoriesView();
                break;
            case 'sales':
                loadSalesView();
                break;
            case 'customers':
                loadCustomersView();
                break;
            case 'coupons':
                loadCouponsView();
                break;
            case 'reports':
                loadReportsView();
                break;
            case 'sync':
                loadSyncView();
                break;
            case 'settings':
                loadSettingsView();
                break;
            default:
                content.innerHTML = `
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-construction fa-3x text-warning mb-3"></i>
                            <h3>Vista en Desarrollo</h3>
                            <p class="text-muted">Esta sección estará disponible pronto</p>
                        </div>
                    </div>
                `;
        }
    }, 100);
}

// ============================================
// CONFIGURACIÓN
// ============================================
async function loadSettings() {
    try {
        const response = await fetch('api/settings.php?action=get_all');
        const data = await response.json();
        
        if (data.success) {
            APP.settings = data.data;
        }
    } catch (error) {
        console.error('Error loading settings:', error);
    }
}

// ============================================
// UTILIDADES
// ============================================
function showToast(title, message, type = 'info') {
    const container = document.getElementById('toastContainer');
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    
    const colors = {
        success: '#10b981',
        error: '#ef4444',
        warning: '#f59e0b',
        info: '#3b82f6'
    };
    
    const toast = document.createElement('div');
    toast.className = 'toast slide-in-up';
    toast.style.borderLeft = `4px solid ${colors[type]}`;
    toast.innerHTML = `
        <i class="fas ${icons[type]}" style="color: ${colors[type]}; font-size: 24px;"></i>
        <div class="toast-content">
            <div class="toast-title">${title}</div>
            <div class="toast-message">${message}</div>
        </div>
        <button class="toast-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    container.appendChild(toast);
    
    // Auto-remove después de 4 segundos
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

function showModal(title, content, buttons = []) {
    const container = document.getElementById('modalContainer');
    
    const buttonsHTML = buttons.map(btn => `
        <button class="btn ${btn.class || 'btn-secondary'}" onclick="${btn.onclick}">
            ${btn.icon ? `<i class="${btn.icon}"></i>` : ''}
            ${btn.text}
        </button>
    `).join('');
    
    container.innerHTML = `
        <div class="modal active">
            <div class="modal-content slide-in-up">
                <div class="modal-header">
                    <h3>${title}</h3>
                    <button class="btn-close" onclick="closeModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    ${content}
                </div>
                <div class="modal-footer">
                    ${buttonsHTML}
                </div>
            </div>
        </div>
    `;
}

function closeModal() {
    const container = document.getElementById('modalContainer');
    container.innerHTML = '';
}

function formatCurrency(amount) {
    const symbol = APP.settings.currency_symbol || '$';
    return symbol + parseFloat(amount).toFixed(2);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-MX', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Helper para llamadas API
async function apiCall(endpoint, data = null, method = 'GET') {
    try {
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            }
        };
        
        if (data && method !== 'GET') {
            options.body = JSON.stringify(data);
        }
        
        const response = await fetch(endpoint, options);
        
        if (response.status === 401) {
            showLogin();
            throw new Error('No autorizado');
        }
        
        return await response.json();
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// Agregar estilos para componentes dinámicos
const dynamicStyles = document.createElement('style');
dynamicStyles.textContent = `
    .loading-screen {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        min-height: 60vh;
    }
    
    .toast-container {
        position: fixed;
        top: 80px;
        right: 20px;
        z-index: 9999;
        display: flex;
        flex-direction: column;
        gap: 10px;
        max-width: 400px;
    }
    
    .toast {
        background: white;
        border-radius: 12px;
        padding: 16px;
        box-shadow: var(--shadow-lg);
        display: flex;
        align-items: center;
        gap: 12px;
        min-width: 300px;
    }
    
    .toast-content {
        flex: 1;
    }
    
    .toast-title {
        font-weight: 600;
        margin-bottom: 4px;
    }
    
    .toast-message {
        font-size: 0.875rem;
        color: var(--gray-600);
    }
    
    .toast-close {
        background: transparent;
        border: none;
        color: var(--gray-400);
        cursor: pointer;
        padding: 4px;
    }
    
    .modal {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        z-index: 9998;
        display: none;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }
    
    .modal.active {
        display: flex;
    }
    
    .modal-content {
        background: white;
        border-radius: 16px;
        max-width: 600px;
        width: 100%;
        max-height: 90vh;
        overflow-y: auto;
        box-shadow: var(--shadow-xl);
    }
    
    .modal-header {
        padding: 24px;
        border-bottom: 2px solid var(--gray-100);
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    
    .modal-body {
        padding: 24px;
    }
    
    .modal-footer {
        padding: 20px 24px;
        border-top: 2px solid var(--gray-100);
        display: flex;
        gap: 10px;
        justify-content: flex-end;
    }
    
    .btn-close {
        background: var(--gray-100);
        border: none;
        width: 32px;
        height: 32px;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--gray-600);
    }
    
    .alert {
        padding: 12px 16px;
        border-radius: 8px;
        margin-top: 16px;
    }
    
    .alert-danger {
        background: #fee2e2;
        border: 1px solid #ef4444;
        color: #991b1b;
    }
    
    @keyframes slideOut {
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(dynamicStyles);

console.log('✅ App inicializada');
