// Utilidades generales
console.log('Utils loaded');
