// Componentes reutilizables
console.log('Components loaded');
