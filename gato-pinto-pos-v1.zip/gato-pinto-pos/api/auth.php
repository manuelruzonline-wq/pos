<?php
/**
 * API de Autenticación
 */
header('Content-Type: application/json');
require_once '../includes/config.php';

// Iniciar sesión si no está iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? ($_GET['action'] ?? '');

try {
    switch($action) {
        case 'login':
            login($pdo, $input);
            break;
        
        case 'logout':
            logout($pdo);
            break;
        
        case 'check':
            checkSession($pdo);
            break;
        
        case 'change_password':
            changePassword($pdo, $input);
            break;
        
        default:
            jsonResponse(false, 'Acción no válida', null, 400);
    }
} catch (Exception $e) {
    if (DEBUG_MODE) {
        jsonResponse(false, $e->getMessage(), null, 500);
    } else {
        jsonResponse(false, 'Error del servidor', null, 500);
    }
}

function login($pdo, $input) {
    $username = cleanInput($input['username'] ?? '');
    $password = $input['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        jsonResponse(false, 'Usuario y contraseña requeridos', null, 400);
    }
    
    // Buscar usuario
    $stmt = $pdo->prepare("
        SELECT id, username, password, email, name, role, active 
        FROM users 
        WHERE username = ? AND active = 1
    ");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if (!$user) {
        logActivity($pdo, 'login_failed', 'user', null, "Usuario no encontrado: $username");
        jsonResponse(false, 'Credenciales incorrectas', null, 401);
    }
    
    // Verificar contraseña
    if (!password_verify($password, $user['password'])) {
        logActivity($pdo, 'login_failed', 'user', $user['id'], "Contraseña incorrecta");
        jsonResponse(false, 'Credenciales incorrectas', null, 401);
    }
    
    // Crear sesión
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['name'] = $user['name'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['login_time'] = time();
    
    // Actualizar último login
    $stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
    $stmt->execute([$user['id']]);
    
    // Log
    logActivity($pdo, 'login', 'user', $user['id'], "Login exitoso");
    
    jsonResponse(true, 'Login exitoso', [
        'user' => [
            'id' => $user['id'],
            'username' => $user['username'],
            'name' => $user['name'],
            'email' => $user['email'],
            'role' => $user['role']
        ]
    ]);
}

function logout($pdo) {
    if (isset($_SESSION['user_id'])) {
        logActivity($pdo, 'logout', 'user', $_SESSION['user_id'], "Logout");
    }
    
    session_destroy();
    jsonResponse(true, 'Sesión cerrada');
}

function checkSession($pdo) {
    if (!isset($_SESSION['user_id'])) {
        jsonResponse(false, 'No hay sesión activa', null, 401);
    }
    
    // Verificar que el usuario aún existe y está activo
    $stmt = $pdo->prepare("SELECT id, username, name, email, role FROM users WHERE id = ? AND active = 1");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    if (!$user) {
        session_destroy();
        jsonResponse(false, 'Usuario no válido', null, 401);
    }
    
    jsonResponse(true, 'Sesión activa', [
        'user' => $user
    ]);
}

function changePassword($pdo, $input) {
    $user = checkAuth();
    
    $current = $input['current_password'] ?? '';
    $new = $input['new_password'] ?? '';
    $confirm = $input['confirm_password'] ?? '';
    
    if (empty($current) || empty($new) || empty($confirm)) {
        jsonResponse(false, 'Todos los campos son requeridos', null, 400);
    }
    
    if ($new !== $confirm) {
        jsonResponse(false, 'Las contraseñas no coinciden', null, 400);
    }
    
    if (strlen($new) < 6) {
        jsonResponse(false, 'La contraseña debe tener al menos 6 caracteres', null, 400);
    }
    
    // Verificar contraseña actual
    $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$user['user_id']]);
    $userData = $stmt->fetch();
    
    if (!password_verify($current, $userData['password'])) {
        jsonResponse(false, 'Contraseña actual incorrecta', null, 401);
    }
    
    // Actualizar contraseña
    $hashed = password_hash($new, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->execute([$hashed, $user['user_id']]);
    
    logActivity($pdo, 'password_changed', 'user', $user['user_id'], "Contraseña cambiada");
    
    jsonResponse(true, 'Contraseña actualizada exitosamente');
}
?>
